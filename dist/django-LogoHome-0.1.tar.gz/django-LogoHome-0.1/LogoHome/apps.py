from django.apps import AppConfig


class LogohomeConfig(AppConfig):
    name = 'LogoHome'
